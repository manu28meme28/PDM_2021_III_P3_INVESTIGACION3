pluginManagement {
    repositories {
        google()
        gradlePluginPortal()
        mavenCentral()
    }
}

rootProject.name = "PDM_2021_III_P3_INVESTIGACION3"
include(":androidApp")
include(":shared")