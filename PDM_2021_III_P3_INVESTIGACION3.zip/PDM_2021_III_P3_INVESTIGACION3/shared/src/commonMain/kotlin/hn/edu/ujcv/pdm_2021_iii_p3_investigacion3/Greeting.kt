package hn.edu.ujcv.pdm_2021_iii_p3_investigacion3

class Greeting {
    fun greeting(): String {
        return "Hello, ${Platform().platform}!"
    }
}