package hn.edu.ujcv.pdm_2021_iii_p3_investigacion3

expect class Platform() {
    val platform: String
}