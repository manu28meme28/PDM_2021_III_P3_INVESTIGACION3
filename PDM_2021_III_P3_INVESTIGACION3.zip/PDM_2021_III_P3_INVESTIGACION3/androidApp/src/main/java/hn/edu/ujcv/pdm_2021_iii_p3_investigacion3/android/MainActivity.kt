package hn.edu.ujcv.pdm_2021_iii_p3_investigacion3.android

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val txvTitle: TextView = findViewById(R.id.txvTitle)
        txvTitle.setText(Title())

        val btnSumar: Button = findViewById(R.id.btnSumar)
        val btnRestar: Button = findViewById(R.id.btnRestar)
        val btnMultiplicar: Button = findViewById(R.id.btnMultiplicar)
        val btnDividir: Button = findViewById(R.id.btnDividir)

        btnSumar.setOnClickListener { Sumar() }
        btnRestar.setOnClickListener { Restar()}
        btnMultiplicar.setOnClickListener { Multiplicar() }
        btnDividir.setOnClickListener { Dividir() }


    }

    fun Sumar() {
        val txvResultado: TextView = findViewById(R.id.txvResultado)
        val txtNumber1: EditText = findViewById(R.id.txtNumber1)
        val txtNumber2: EditText = findViewById(R.id.txtNumber2)

        val num1: Int = Integer.parseInt(txtNumber1.text.toString())
        val num2: Int = Integer.parseInt(txtNumber2.text.toString())
        val result1 = num1 + num2
        txvResultado.setText(result1.toString())
    }

    fun Restar() {
        val txvResultado: TextView = findViewById(R.id.txvResultado)
        val txtNumber3: EditText = findViewById(R.id.txtNumber3)
        val txtNumber4: EditText = findViewById(R.id.txtNumber4)

        val num3: Int = Integer.parseInt(txtNumber3.text.toString())
        val num4: Int = Integer.parseInt(txtNumber4.text.toString())
        val result2 = num3 - num4
        txvResultado.setText(result2.toString())
    }

    fun Multiplicar() {
        val txvResultado: TextView = findViewById(R.id.txvResultado)
        val txtNumber5: EditText = findViewById(R.id.txtNumber5)
        val txtNumber6: EditText = findViewById(R.id.txtNumber6)

        val num5: Int = Integer.parseInt(txtNumber5.text.toString())
        val num6: Int = Integer.parseInt(txtNumber6.text.toString())
        val result3 = num5 * num6
        txvResultado.setText(result3.toString())
    }

    fun Dividir() {
        val txvResultado: TextView = findViewById(R.id.txvResultado)
        val txtNumber7: EditText = findViewById(R.id.txtNumber7)
        val txtNumber8: EditText = findViewById(R.id.txtNumber8)

        val num7: Int = Integer.parseInt(txtNumber7.text.toString())
        val num8: Int = Integer.parseInt(txtNumber8.text.toString())
        val result4 = num7 / num8
        txvResultado.setText(result4.toString())
    }
    fun Title():String{
        return "Multiplicar & Dividir"
    }

}
